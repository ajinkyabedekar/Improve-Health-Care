from django.apps import AppConfig


class PreventativeConfig(AppConfig):
    name = 'preventative'
